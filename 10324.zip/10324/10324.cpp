#include <iostream>
#include <string>

using namespace std;

/* LIMITE DE TEMPO*/
int main(int argc, char const *argv[]) {
   int i = 1;
   int cases;
   string sequence;
   int x, y;

   while(cin >> sequence){
      cout << "Case " << i << ":\n";
      cin >> cases;
      while(cases > 0){
         cin >> x >> y;
         bool equals = true;
         for(int i = x; i < y; i++){
            if(sequence[i] != sequence[i+1]){
               equals = false;
               break;
            }
         }
         if(equals){
            cout << "Yes\n";
         }else{
            cout << "No\n";
         }
         cases--;
      }
      i++;
   }

   return 0;
}

/* RESPOSTA ERRADA (?):
int main(int argc, char const *argv[]) {
   int i = 1;
   int cases;
   char sequence[1000000];
   int x, y;

   while(cin >> sequence){
      cout << "Case " << i << ":\n";
      //cout << sequence << "\n";
      cin >> cases;
      while(cases > 0){
         cin >> x >> y;
         bool equals = true;
         for(int i = x; i < y; i++){
            if(sequence[i] != sequence[i+1]){
               equals = false;
               break;
            }
         }
         if(equals){
            cout << "Yes\n";
         }else{
            cout << "No\n";
         }
         cases--;
      }
      i++;
   }

   return 0;
}*/
